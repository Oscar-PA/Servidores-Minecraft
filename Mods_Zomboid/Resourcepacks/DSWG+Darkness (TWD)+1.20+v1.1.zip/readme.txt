﻿DSWG Darkness v1.1
For Optifine 1.13 - 1.20+
By Daswaget
Patreon: https://www.patreon.com/daswaget

DSWG = Daswaget